import psycopg2
import psycopg2.extras
from psycopg2 import sql
from typing import Optional


class ApplianceDB:

    def __init__(self, host: str, port: int, dbname: str, user: str, password: str):
        self.conn = psycopg2.connect(
            host=host,
            port=port,
            dbname=dbname,
            user=user,
            password=password
        )
        self.conn.autocommit = False

    def _cursor(self):
        return self.conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

    def _commit(self):
        self.conn.commit()

    def _rollback(self):
        self.conn.rollback()

    def close(self):
        self.conn.close()

    # ------------------------------------------------------------------ #
    #  LOCATIONS                                                           #
    # ------------------------------------------------------------------ #

    def add_location(self, country_name: str, iso_code: str, latitude: float, longitude: float):
        with self._cursor() as cur:
            cur.execute(
                """
                INSERT INTO locations (country_name, iso_code, latitude, longitude)
                VALUES (%s, %s, %s, %s)
                RETURNING *
                """,
                (country_name, iso_code, latitude, longitude)
            )
            result = cur.fetchone()
            self._commit()
            return result

    def get_location(self, location_id: int):
        with self._cursor() as cur:
            cur.execute("SELECT * FROM locations WHERE location_id = %s", (location_id,))
            return cur.fetchone()

    def get_all_locations(self):
        with self._cursor() as cur:
            cur.execute("SELECT * FROM locations ORDER BY country_name")
            return cur.fetchall()

    def update_location(self, location_id: int, country_name: str, iso_code: str, latitude: float, longitude: float):
        with self._cursor() as cur:
            cur.execute(
                """
                UPDATE locations
                SET country_name = %s, iso_code = %s, latitude = %s, longitude = %s
                WHERE location_id = %s
                RETURNING *
                """,
                (country_name, iso_code, latitude, longitude, location_id)
            )
            result = cur.fetchone()
            self._commit()
            return result

    def delete_location(self, location_id: int):
        with self._cursor() as cur:
            cur.execute("DELETE FROM locations WHERE location_id = %s RETURNING location_id", (location_id,))
            result = cur.fetchone()
            self._commit()
            return result

    # ------------------------------------------------------------------ #
    #  MANUFACTURERS                                                       #
    # ------------------------------------------------------------------ #

    def add_manufacturer(self, name: str, location_id: int, website: Optional[str] = None):
        with self._cursor() as cur:
            cur.execute(
                """
                INSERT INTO manufacturers (name, location_id, website)
                VALUES (%s, %s, %s)
                RETURNING *
                """,
                (name, location_id, website)
            )
            result = cur.fetchone()
            self._commit()
            return result

    def get_manufacturer(self, manufacturer_id: int):
        with self._cursor() as cur:
            cur.execute(
                """
                SELECT m.*, l.country_name, l.iso_code
                FROM manufacturers m
                JOIN locations l ON m.location_id = l.location_id
                WHERE m.manufacturer_id = %s
                """,
                (manufacturer_id,)
            )
            return cur.fetchone()

    def get_all_manufacturers(self):
        with self._cursor() as cur:
            cur.execute(
                """
                SELECT m.*, l.country_name
                FROM manufacturers m
                JOIN locations l ON m.location_id = l.location_id
                ORDER BY m.name
                """
            )
            return cur.fetchall()

    def get_manufacturers_by_country(self, country_name: str):
        with self._cursor() as cur:
            cur.execute(
                """
                SELECT m.* FROM manufacturers m
                JOIN locations l ON m.location_id = l.location_id
                WHERE l.country_name ILIKE %s
                """,
                (country_name,)
            )
            return cur.fetchall()

    def update_manufacturer(self, manufacturer_id: int, name: str, location_id: int, website: Optional[str] = None):
        with self._cursor() as cur:
            cur.execute(
                """
                UPDATE manufacturers
                SET name = %s, location_id = %s, website = %s
                WHERE manufacturer_id = %s
                RETURNING *
                """,
                (name, location_id, website, manufacturer_id)
            )
            result = cur.fetchone()
            self._commit()
            return result

    def delete_manufacturer(self, manufacturer_id: int):
        with self._cursor() as cur:
            cur.execute("DELETE FROM manufacturers WHERE manufacturer_id = %s RETURNING manufacturer_id", (manufacturer_id,))
            result = cur.fetchone()
            self._commit()
            return result

    # ------------------------------------------------------------------ #
    #  CATEGORIES                                                          #
    # ------------------------------------------------------------------ #

    def add_category(self, name: str, description: Optional[str] = None):
        with self._cursor() as cur:
            cur.execute(
                """
                INSERT INTO categories (name, description)
                VALUES (%s, %s)
                RETURNING *
                """,
                (name, description)
            )
            result = cur.fetchone()
            self._commit()
            return result

    def get_category(self, category_id: int):
        with self._cursor() as cur:
            cur.execute("SELECT * FROM categories WHERE category_id = %s", (category_id,))
            return cur.fetchone()

    def get_all_categories(self):
        with self._cursor() as cur:
            cur.execute("SELECT * FROM categories ORDER BY name")
            return cur.fetchall()

    def update_category(self, category_id: int, name: str, description: Optional[str] = None):
        with self._cursor() as cur:
            cur.execute(
                """
                UPDATE categories SET name = %s, description = %s
                WHERE category_id = %s
                RETURNING *
                """,
                (name, description, category_id)
            )
            result = cur.fetchone()
            self._commit()
            return result

    def delete_category(self, category_id: int):
        with self._cursor() as cur:
            cur.execute("DELETE FROM categories WHERE category_id = %s RETURNING category_id", (category_id,))
            result = cur.fetchone()
            self._commit()
            return result

    # ------------------------------------------------------------------ #
    #  APPLIANCES                                                          #
    # ------------------------------------------------------------------ #

    def add_appliance(self, name: str, category_id: int, manufacturer_id: int,
                      min_consumption: float, max_consumption: float):
        with self._cursor() as cur:
            cur.execute(
                """
                INSERT INTO appliances (name, category_id, manufacturer_id, min_consumption, max_consumption)
                VALUES (%s, %s, %s, %s, %s)
                RETURNING *
                """,
                (name, category_id, manufacturer_id, min_consumption, max_consumption)
            )
            result = cur.fetchone()
            self._commit()
            return result

    def get_appliance(self, appliance_id: int):
        with self._cursor() as cur:
            cur.execute(
                """
                SELECT a.*, c.name AS category, m.name AS manufacturer, l.country_name
                FROM appliances a
                JOIN categories    c ON a.category_id     = c.category_id
                JOIN manufacturers m ON a.manufacturer_id = m.manufacturer_id
                JOIN locations     l ON m.location_id     = l.location_id
                WHERE a.appliance_id = %s
                """,
                (appliance_id,)
            )
            return cur.fetchone()

    def get_all_appliances(self):
        with self._cursor() as cur:
            cur.execute(
                """
                SELECT a.*, c.name AS category, m.name AS manufacturer, l.country_name
                FROM appliances a
                JOIN categories    c ON a.category_id     = c.category_id
                JOIN manufacturers m ON a.manufacturer_id = m.manufacturer_id
                JOIN locations     l ON m.location_id     = l.location_id
                ORDER BY a.name
                """
            )
            return cur.fetchall()

    def get_appliances_by_name(self, name: str):
        with self._cursor() as cur:
            cur.execute(
                """
                SELECT a.*, c.name AS category, m.name AS manufacturer
                FROM appliances a
                JOIN categories    c ON a.category_id     = c.category_id
                JOIN manufacturers m ON a.manufacturer_id = m.manufacturer_id
                WHERE a.name ILIKE %s
                """,
                (f"%{name}%",)
            )
            return cur.fetchall()

    def get_appliances_by_category(self, category_name: str):
        with self._cursor() as cur:
            cur.execute(
                """
                SELECT a.*, m.name AS manufacturer
                FROM appliances a
                JOIN categories    c ON a.category_id     = c.category_id
                JOIN manufacturers m ON a.manufacturer_id = m.manufacturer_id
                WHERE c.name ILIKE %s
                """,
                (category_name,)
            )
            return cur.fetchall()

    def get_appliances_by_manufacturer(self, manufacturer_name: str):
        with self._cursor() as cur:
            cur.execute(
                """
                SELECT a.*, c.name AS category
                FROM appliances a
                JOIN categories    c ON a.category_id     = c.category_id
                JOIN manufacturers m ON a.manufacturer_id = m.manufacturer_id
                WHERE m.name ILIKE %s
                """,
                (manufacturer_name,)
            )
            return cur.fetchall()

    def get_appliances_by_country(self, country_name: str):
        with self._cursor() as cur:
            cur.execute(
                """
                SELECT a.*, c.name AS category, m.name AS manufacturer, l.country_name
                FROM appliances a
                JOIN categories    c ON a.category_id     = c.category_id
                JOIN manufacturers m ON a.manufacturer_id = m.manufacturer_id
                JOIN locations     l ON m.location_id     = l.location_id
                WHERE l.country_name ILIKE %s
                """,
                (country_name,)
            )
            return cur.fetchall()

    def get_appliances_by_consumption(self, min_kwh: float, max_kwh: float):
        with self._cursor() as cur:
            cur.execute(
                """
                SELECT a.*, c.name AS category
                FROM appliances a
                JOIN categories c ON a.category_id = c.category_id
                WHERE a.min_consumption >= %s AND a.max_consumption <= %s
                ORDER BY a.min_consumption ASC
                """,
                (min_kwh, max_kwh)
            )
            return cur.fetchall()

    def update_appliance(self, appliance_id: int, name: str, category_id: int,
                         manufacturer_id: int, min_consumption: float, max_consumption: float):
        with self._cursor() as cur:
            cur.execute(
                """
                UPDATE appliances
                SET name = %s, category_id = %s, manufacturer_id = %s,
                    min_consumption = %s, max_consumption = %s
                WHERE appliance_id = %s
                RETURNING *
                """,
                (name, category_id, manufacturer_id, min_consumption, max_consumption, appliance_id)
            )
            result = cur.fetchone()
            self._commit()
            return result

    def delete_appliance(self, appliance_id: int):
        with self._cursor() as cur:
            cur.execute("DELETE FROM appliances WHERE appliance_id = %s RETURNING appliance_id", (appliance_id,))
            result = cur.fetchone()
            self._commit()
            return result

    # ------------------------------------------------------------------ #
    #  IMAGES                                                              #
    # ------------------------------------------------------------------ #

    def add_category_image(self, file_name: str, mime_type: str, image_data: bytes,
                           category_id: int, file_size: Optional[int] = None, alt_text: Optional[str] = None):
        with self._cursor() as cur:
            cur.execute(
                """
                INSERT INTO images (file_name, file_size, mime_type, alt_text, image_data, category_id)
                VALUES (%s, %s, %s, %s, %s, %s)
                RETURNING image_id, file_name, mime_type, category_id, appliance_id, uploaded_at
                """,
                (file_name, file_size, mime_type, alt_text, psycopg2.Binary(image_data), category_id)
            )
            result = cur.fetchone()
            self._commit()
            return result

    def add_appliance_image(self, file_name: str, mime_type: str, image_data: bytes,
                            appliance_id: int, file_size: Optional[int] = None, alt_text: Optional[str] = None):
        with self._cursor() as cur:
            cur.execute(
                """
                INSERT INTO images (file_name, file_size, mime_type, alt_text, image_data, category_id, appliance_id)
                SELECT %s, %s, %s, %s, %s, a.category_id, a.appliance_id
                FROM appliances a WHERE a.appliance_id = %s
                RETURNING image_id, file_name, mime_type, category_id, appliance_id, uploaded_at
                """,
                (file_name, file_size, mime_type, alt_text, psycopg2.Binary(image_data), appliance_id)
            )
            result = cur.fetchone()
            self._commit()
            return result

    def get_images_by_appliance(self, appliance_id: int):
        with self._cursor() as cur:
            cur.execute(
                "SELECT image_id, file_name, mime_type, alt_text, file_size, uploaded_at FROM images WHERE appliance_id = %s",
                (appliance_id,)
            )
            return cur.fetchall()

    def get_images_by_category(self, category_id: int, category_wide_only: bool = False):
        with self._cursor() as cur:
            query = """
                SELECT image_id, file_name, mime_type, alt_text, file_size, uploaded_at,
                       appliance_id
                FROM images
                WHERE category_id = %s
            """
            if category_wide_only:
                query += " AND appliance_id IS NULL"
            cur.execute(query, (category_id,))
            return cur.fetchall()

    def get_image_data(self, image_id: int):
        with self._cursor() as cur:
            cur.execute("SELECT * FROM images WHERE image_id = %s", (image_id,))
            return cur.fetchone()

    def get_all_images_for_appliance(self, appliance_id: int):
        with self._cursor() as cur:
            cur.execute(
                """
                SELECT i.image_id, i.file_name, i.mime_type, i.alt_text, i.image_data,
                       CASE WHEN i.appliance_id IS NOT NULL THEN 'appliance-specific' ELSE 'category-wide' END AS image_type
                FROM appliances a
                JOIN images i ON i.category_id = a.category_id
                WHERE a.appliance_id = %s
                ORDER BY image_type DESC
                """,
                (appliance_id,)
            )
            return cur.fetchall()

    def delete_image(self, image_id: int):
        with self._cursor() as cur:
            cur.execute("DELETE FROM images WHERE image_id = %s RETURNING image_id", (image_id,))
            result = cur.fetchone()
            self._commit()
            return result

    # ------------------------------------------------------------------ #
    #  CLIMATE DATA                                                        #
    # ------------------------------------------------------------------ #

    def upsert_climate_data(self, location_id: int, year: Optional[int], month: int,
                            is_climatology: bool, t2m: float = None, t2m_max: float = None,
                            t2m_min: float = None, prectotcorr: float = None, rh2m: float = None,
                            ws2m: float = None, t2mdew: float = None, ws10m: float = None,
                            ps: float = None, allsky_sfc_sw_dwn: float = None):
        with self._cursor() as cur:
            cur.execute(
                """
                INSERT INTO climate_data (
                    location_id, year, month, is_climatology,
                    t2m, t2m_max, t2m_min, prectotcorr,
                    rh2m, ws2m, t2mdew, ws10m, ps, allsky_sfc_sw_dwn
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (location_id, year, month, is_climatology)
                DO UPDATE SET
                    t2m               = EXCLUDED.t2m,
                    t2m_max           = EXCLUDED.t2m_max,
                    t2m_min           = EXCLUDED.t2m_min,
                    prectotcorr       = EXCLUDED.prectotcorr,
                    rh2m              = EXCLUDED.rh2m,
                    ws2m              = EXCLUDED.ws2m,
                    t2mdew            = EXCLUDED.t2mdew,
                    ws10m             = EXCLUDED.ws10m,
                    ps                = EXCLUDED.ps,
                    allsky_sfc_sw_dwn = EXCLUDED.allsky_sfc_sw_dwn,
                    fetched_at        = NOW()
                RETURNING *
                """,
                (location_id, year, month, is_climatology, t2m, t2m_max, t2m_min,
                 prectotcorr, rh2m, ws2m, t2mdew, ws10m, ps, allsky_sfc_sw_dwn)
            )
            result = cur.fetchone()
            self._commit()
            return result

    def get_climate_by_country(self, country_name: str, year: int):
        with self._cursor() as cur:
            cur.execute(
                """
                SELECT cd.* FROM climate_data cd
                JOIN locations l ON cd.location_id = l.location_id
                WHERE l.country_name ILIKE %s AND cd.year = %s AND cd.is_climatology = FALSE
                ORDER BY cd.month
                """,
                (country_name, year)
            )
            return cur.fetchall()

    def get_climatology_by_country(self, country_name: str):
        with self._cursor() as cur:
            cur.execute(
                """
                SELECT cd.* FROM climate_data cd
                JOIN locations l ON cd.location_id = l.location_id
                WHERE l.country_name ILIKE %s AND cd.is_climatology = TRUE
                ORDER BY cd.month
                """,
                (country_name,)
            )
            return cur.fetchall()

    def get_climate_by_month(self, month: int, is_climatology: bool = False):
        with self._cursor() as cur:
            cur.execute(
                """
                SELECT l.country_name, cd.*
                FROM climate_data cd
                JOIN locations l ON cd.location_id = l.location_id
                WHERE cd.month = %s AND cd.is_climatology = %s
                ORDER BY l.country_name
                """,
                (month, is_climatology)
            )
            return cur.fetchall()

    def get_annual_climate_summary(self):
        with self._cursor() as cur:
            cur.execute(
                """
                SELECT
                    l.country_name,
                    cd.year,
                    ROUND(AVG(cd.t2m)::NUMERIC, 2)         AS avg_temp,
                    ROUND(AVG(cd.t2m_max)::NUMERIC, 2)     AS avg_max_temp,
                    ROUND(AVG(cd.t2m_min)::NUMERIC, 2)     AS avg_min_temp,
                    ROUND(AVG(cd.rh2m)::NUMERIC, 2)        AS avg_humidity,
                    ROUND(SUM(cd.prectotcorr)::NUMERIC, 2) AS total_precipitation
                FROM climate_data cd
                JOIN locations l ON cd.location_id = l.location_id
                WHERE cd.is_climatology = FALSE
                GROUP BY l.country_name, cd.year
                ORDER BY l.country_name, cd.year
                """
            )
            return cur.fetchall()

    def delete_climate_data(self, climate_id: int):
        with self._cursor() as cur:
            cur.execute("DELETE FROM climate_data WHERE climate_id = %s RETURNING climate_id", (climate_id,))
            result = cur.fetchone()
            self._commit()
            return result

    # ------------------------------------------------------------------ #
    #  ANALYTICS                                                           #
    # ------------------------------------------------------------------ #

    def get_appliance_count_by_category(self):
        with self._cursor() as cur:
            cur.execute(
                """
                SELECT c.name AS category, COUNT(a.appliance_id) AS total
                FROM categories c
                LEFT JOIN appliances a ON c.category_id = a.category_id
                GROUP BY c.category_id, c.name
                ORDER BY total DESC
                """
            )
            return cur.fetchall()

    def get_avg_consumption_by_category(self):
        with self._cursor() as cur:
            cur.execute(
                """
                SELECT
                    c.name AS category,
                    ROUND(AVG(a.min_consumption)::NUMERIC, 2) AS avg_min,
                    ROUND(AVG(a.max_consumption)::NUMERIC, 2) AS avg_max
                FROM appliances a
                JOIN categories c ON a.category_id = c.category_id
                GROUP BY c.category_id, c.name
                ORDER BY avg_max DESC
                """
            )
            return cur.fetchall()

    def get_top_consumption_appliances(self, limit: int = 10):
        with self._cursor() as cur:
            cur.execute(
                """
                SELECT a.name, a.max_consumption, c.name AS category, m.name AS manufacturer
                FROM appliances a
                JOIN categories    c ON a.category_id     = c.category_id
                JOIN manufacturers m ON a.manufacturer_id = m.manufacturer_id
                ORDER BY a.max_consumption DESC
                LIMIT %s
                """,
                (limit,)
            )
            return cur.fetchall()

    def get_appliance_count_by_country(self):
        with self._cursor() as cur:
            cur.execute(
                """
                SELECT l.country_name, COUNT(a.appliance_id) AS total
                FROM appliances a
                JOIN manufacturers m ON a.manufacturer_id = m.manufacturer_id
                JOIN locations     l ON m.location_id     = l.location_id
                GROUP BY l.country_name
                ORDER BY total DESC
                """
            )
            return cur.fetchall()

    def get_categories_without_images(self):
        with self._cursor() as cur:
            cur.execute(
                """
                SELECT c.category_id, c.name
                FROM categories c
                LEFT JOIN images i ON c.category_id = i.category_id
                WHERE i.image_id IS NULL
                """
            )
            return cur.fetchall()

    def get_manufacturers_without_appliances(self):
        with self._cursor() as cur:
            cur.execute(
                """
                SELECT m.manufacturer_id, m.name, l.country_name
                FROM manufacturers m
                JOIN locations     l ON m.location_id = l.location_id
                LEFT JOIN appliances a ON a.manufacturer_id = m.manufacturer_id
                WHERE a.appliance_id IS NULL
                """
            )
            return cur.fetchall()