1. Include AIR_CONDITIONERS COOLING CAPACITY IN DATABASE SCHEMA for Auditing Simulations
2. Dishwashers calculated as watt/rack