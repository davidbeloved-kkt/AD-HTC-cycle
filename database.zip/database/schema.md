# SCHEMA GUIDE
`### Database Written in PostgreSQL`

Structure is first described in python before ported to SQL.
``` python
@dataclass
class Electronic:
    id: int
    country_id: int
    category_id: int
    min_power_consumption: float
    max_power_consumption: float
    min_price: float
    max_price: float
```

```sql

```