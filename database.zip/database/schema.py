from dataclasses import dataclass

@dataclass
class Country:
    id: int
    name: str
    currency: str

@dataclass
class ElectronicCategory:
    id: int
    name: str

@dataclass
class Electronic:
    id: int
    country_id: int
    category_id: int
    min_power_consumption: float
    max_power_consumption: float








